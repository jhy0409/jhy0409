﻿
namespace Chapter05
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.button_test = new System.Windows.Forms.Button();
            this.label_num1 = new System.Windows.Forms.Label();
            this.label_num2 = new System.Windows.Forms.Label();
            this.label_num3 = new System.Windows.Forms.Label();
            this.label_num4 = new System.Windows.Forms.Label();
            this.label_num5 = new System.Windows.Forms.Label();
            this.label_num6 = new System.Windows.Forms.Label();
            this.label_num7 = new System.Windows.Forms.Label();
            this.thisPcent_7 = new System.Windows.Forms.Label();
            this.thisPcent_4 = new System.Windows.Forms.Label();
            this.thisPcent_5 = new System.Windows.Forms.Label();
            this.thisPcent_6 = new System.Windows.Forms.Label();
            this.thisPcent_3 = new System.Windows.Forms.Label();
            this.thisPcent_2 = new System.Windows.Forms.Label();
            this.thisPcent_1 = new System.Windows.Forms.Label();
            this.gongImg_7 = new System.Windows.Forms.PictureBox();
            this.gongImg_6 = new System.Windows.Forms.PictureBox();
            this.gongImg_5 = new System.Windows.Forms.PictureBox();
            this.gongImg_4 = new System.Windows.Forms.PictureBox();
            this.lottoLogo = new System.Windows.Forms.PictureBox();
            this.gongImg_3 = new System.Windows.Forms.PictureBox();
            this.gongImg_2 = new System.Windows.Forms.PictureBox();
            this.gongImg_1 = new System.Windows.Forms.PictureBox();
            this.HelpLabelTxt = new Sunny.UI.UILabel();
            this.makeRandTxtBox = new VerticalTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lottoLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_test
            // 
            this.button_test.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.button_test.Location = new System.Drawing.Point(458, 205);
            this.button_test.MinimumSize = new System.Drawing.Size(80, 30);
            this.button_test.Name = "button_test";
            this.button_test.Size = new System.Drawing.Size(80, 40);
            this.button_test.TabIndex = 1;
            this.button_test.Text = "확인";
            this.button_test.UseVisualStyleBackColor = true;
            this.button_test.Click += new System.EventHandler(this.button_test_Click);
            // 
            // label_num1
            // 
            this.label_num1.AutoSize = true;
            this.label_num1.BackColor = System.Drawing.Color.Transparent;
            this.label_num1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num1.Location = new System.Drawing.Point(150, 350);
            this.label_num1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num1.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num1.Name = "label_num1";
            this.label_num1.Size = new System.Drawing.Size(45, 20);
            this.label_num1.TabIndex = 1;
            this.label_num1.Text = "00";
            this.label_num1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num2
            // 
            this.label_num2.AutoSize = true;
            this.label_num2.BackColor = System.Drawing.Color.Transparent;
            this.label_num2.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num2.Location = new System.Drawing.Point(226, 350);
            this.label_num2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num2.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num2.Name = "label_num2";
            this.label_num2.Size = new System.Drawing.Size(45, 20);
            this.label_num2.TabIndex = 2;
            this.label_num2.Text = "00";
            this.label_num2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num3
            // 
            this.label_num3.AutoSize = true;
            this.label_num3.BackColor = System.Drawing.Color.Transparent;
            this.label_num3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num3.Location = new System.Drawing.Point(302, 350);
            this.label_num3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num3.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num3.Name = "label_num3";
            this.label_num3.Size = new System.Drawing.Size(45, 20);
            this.label_num3.TabIndex = 3;
            this.label_num3.Text = "00";
            this.label_num3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num4
            // 
            this.label_num4.AutoSize = true;
            this.label_num4.BackColor = System.Drawing.Color.Transparent;
            this.label_num4.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num4.Location = new System.Drawing.Point(378, 350);
            this.label_num4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num4.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num4.Name = "label_num4";
            this.label_num4.Size = new System.Drawing.Size(45, 20);
            this.label_num4.TabIndex = 6;
            this.label_num4.Text = "00";
            this.label_num4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num5
            // 
            this.label_num5.AutoSize = true;
            this.label_num5.BackColor = System.Drawing.Color.Transparent;
            this.label_num5.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num5.Location = new System.Drawing.Point(454, 350);
            this.label_num5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num5.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num5.Name = "label_num5";
            this.label_num5.Size = new System.Drawing.Size(45, 20);
            this.label_num5.TabIndex = 5;
            this.label_num5.Text = "00";
            this.label_num5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num6
            // 
            this.label_num6.AutoSize = true;
            this.label_num6.BackColor = System.Drawing.Color.Transparent;
            this.label_num6.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num6.Location = new System.Drawing.Point(530, 350);
            this.label_num6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num6.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num6.Name = "label_num6";
            this.label_num6.Size = new System.Drawing.Size(45, 20);
            this.label_num6.TabIndex = 4;
            this.label_num6.Text = "00";
            this.label_num6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num7
            // 
            this.label_num7.AutoSize = true;
            this.label_num7.BackColor = System.Drawing.Color.Transparent;
            this.label_num7.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num7.Location = new System.Drawing.Point(606, 350);
            this.label_num7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_num7.MinimumSize = new System.Drawing.Size(45, 20);
            this.label_num7.Name = "label_num7";
            this.label_num7.Size = new System.Drawing.Size(45, 20);
            this.label_num7.TabIndex = 7;
            this.label_num7.Text = "00";
            this.label_num7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_7
            // 
            this.thisPcent_7.AutoSize = true;
            this.thisPcent_7.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_7.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_7.Location = new System.Drawing.Point(606, 413);
            this.thisPcent_7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_7.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_7.Name = "thisPcent_7";
            this.thisPcent_7.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_7.TabIndex = 15;
            this.thisPcent_7.Text = "00";
            this.thisPcent_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_4
            // 
            this.thisPcent_4.AutoSize = true;
            this.thisPcent_4.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_4.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_4.Location = new System.Drawing.Point(378, 413);
            this.thisPcent_4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_4.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_4.Name = "thisPcent_4";
            this.thisPcent_4.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_4.TabIndex = 14;
            this.thisPcent_4.Text = "00";
            this.thisPcent_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_5
            // 
            this.thisPcent_5.AutoSize = true;
            this.thisPcent_5.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_5.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_5.Location = new System.Drawing.Point(454, 413);
            this.thisPcent_5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_5.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_5.Name = "thisPcent_5";
            this.thisPcent_5.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_5.TabIndex = 13;
            this.thisPcent_5.Text = "00";
            this.thisPcent_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_6
            // 
            this.thisPcent_6.AutoSize = true;
            this.thisPcent_6.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_6.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_6.Location = new System.Drawing.Point(530, 413);
            this.thisPcent_6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_6.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_6.Name = "thisPcent_6";
            this.thisPcent_6.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_6.TabIndex = 12;
            this.thisPcent_6.Text = "00";
            this.thisPcent_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_3
            // 
            this.thisPcent_3.AutoSize = true;
            this.thisPcent_3.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_3.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_3.Location = new System.Drawing.Point(302, 413);
            this.thisPcent_3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_3.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_3.Name = "thisPcent_3";
            this.thisPcent_3.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_3.TabIndex = 11;
            this.thisPcent_3.Text = "00";
            this.thisPcent_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_2
            // 
            this.thisPcent_2.AutoSize = true;
            this.thisPcent_2.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_2.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_2.Location = new System.Drawing.Point(226, 413);
            this.thisPcent_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_2.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_2.Name = "thisPcent_2";
            this.thisPcent_2.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_2.TabIndex = 10;
            this.thisPcent_2.Text = "00";
            this.thisPcent_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thisPcent_1
            // 
            this.thisPcent_1.AutoSize = true;
            this.thisPcent_1.BackColor = System.Drawing.Color.Transparent;
            this.thisPcent_1.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.thisPcent_1.Location = new System.Drawing.Point(150, 413);
            this.thisPcent_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.thisPcent_1.MinimumSize = new System.Drawing.Size(45, 20);
            this.thisPcent_1.Name = "thisPcent_1";
            this.thisPcent_1.Size = new System.Drawing.Size(45, 20);
            this.thisPcent_1.TabIndex = 9;
            this.thisPcent_1.Text = "00";
            this.thisPcent_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gongImg_7
            // 
            this.gongImg_7.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_7.Image = global::Chapter05.Properties.Resources.lt_img7;
            this.gongImg_7.Location = new System.Drawing.Point(594, 327);
            this.gongImg_7.Name = "gongImg_7";
            this.gongImg_7.Size = new System.Drawing.Size(70, 70);
            this.gongImg_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_7.TabIndex = 23;
            this.gongImg_7.TabStop = false;
            // 
            // gongImg_6
            // 
            this.gongImg_6.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_6.Image = global::Chapter05.Properties.Resources.lt_img6;
            this.gongImg_6.Location = new System.Drawing.Point(518, 327);
            this.gongImg_6.Name = "gongImg_6";
            this.gongImg_6.Size = new System.Drawing.Size(70, 70);
            this.gongImg_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_6.TabIndex = 22;
            this.gongImg_6.TabStop = false;
            // 
            // gongImg_5
            // 
            this.gongImg_5.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_5.Image = global::Chapter05.Properties.Resources.lt_img5;
            this.gongImg_5.Location = new System.Drawing.Point(442, 327);
            this.gongImg_5.Name = "gongImg_5";
            this.gongImg_5.Size = new System.Drawing.Size(70, 70);
            this.gongImg_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_5.TabIndex = 21;
            this.gongImg_5.TabStop = false;
            // 
            // gongImg_4
            // 
            this.gongImg_4.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_4.Image = global::Chapter05.Properties.Resources.lt_img4;
            this.gongImg_4.Location = new System.Drawing.Point(366, 327);
            this.gongImg_4.Name = "gongImg_4";
            this.gongImg_4.Size = new System.Drawing.Size(70, 70);
            this.gongImg_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_4.TabIndex = 20;
            this.gongImg_4.TabStop = false;
            // 
            // lottoLogo
            // 
            this.lottoLogo.BackColor = System.Drawing.Color.Transparent;
            this.lottoLogo.Image = ((System.Drawing.Image)(resources.GetObject("lottoLogo.Image")));
            this.lottoLogo.Location = new System.Drawing.Point(260, 79);
            this.lottoLogo.Margin = new System.Windows.Forms.Padding(200, 30, 4, 5);
            this.lottoLogo.Name = "lottoLogo";
            this.lottoLogo.Size = new System.Drawing.Size(280, 100);
            this.lottoLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lottoLogo.TabIndex = 16;
            this.lottoLogo.TabStop = false;
            // 
            // gongImg_3
            // 
            this.gongImg_3.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_3.Image = global::Chapter05.Properties.Resources.lt_img3;
            this.gongImg_3.Location = new System.Drawing.Point(289, 327);
            this.gongImg_3.Name = "gongImg_3";
            this.gongImg_3.Size = new System.Drawing.Size(70, 70);
            this.gongImg_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_3.TabIndex = 19;
            this.gongImg_3.TabStop = false;
            // 
            // gongImg_2
            // 
            this.gongImg_2.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_2.Image = global::Chapter05.Properties.Resources.lt_img2;
            this.gongImg_2.Location = new System.Drawing.Point(213, 327);
            this.gongImg_2.Name = "gongImg_2";
            this.gongImg_2.Size = new System.Drawing.Size(70, 70);
            this.gongImg_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_2.TabIndex = 18;
            this.gongImg_2.TabStop = false;
            // 
            // gongImg_1
            // 
            this.gongImg_1.BackColor = System.Drawing.Color.Transparent;
            this.gongImg_1.Image = global::Chapter05.Properties.Resources.lt_img1;
            this.gongImg_1.Location = new System.Drawing.Point(137, 327);
            this.gongImg_1.Name = "gongImg_1";
            this.gongImg_1.Size = new System.Drawing.Size(70, 70);
            this.gongImg_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gongImg_1.TabIndex = 17;
            this.gongImg_1.TabStop = false;
            // 
            // HelpLabelTxt
            // 
            this.HelpLabelTxt.BackColor = System.Drawing.Color.Transparent;
            this.HelpLabelTxt.Font = new System.Drawing.Font("Microsoft YaHei", 13F);
            this.HelpLabelTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.HelpLabelTxt.Location = new System.Drawing.Point(742, 9);
            this.HelpLabelTxt.Name = "HelpLabelTxt";
            this.HelpLabelTxt.Size = new System.Drawing.Size(30, 30);
            this.HelpLabelTxt.TabIndex = 25;
            this.HelpLabelTxt.Text = "?";
            this.HelpLabelTxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // makeRandTxtBox
            // 
            this.makeRandTxtBox.BackColor = System.Drawing.SystemColors.Window;
            this.makeRandTxtBox.BorderColor = System.Drawing.Color.Gray;
            this.makeRandTxtBox.LeftRightPadding = ((uint)(10u));
            this.makeRandTxtBox.Location = new System.Drawing.Point(260, 205);
            this.makeRandTxtBox.Name = "makeRandTxtBox";
            this.makeRandTxtBox.Size = new System.Drawing.Size(192, 40);
            this.makeRandTxtBox.TabIndex = 24;
            this.makeRandTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.makeRandTxtBox.Enter += new System.EventHandler(this.makeRandTxtBox_Enter);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Chapter05.Properties.Resources.mainBg_gray;
            this.ClientSize = new System.Drawing.Size(784, 501);
            this.Controls.Add(this.HelpLabelTxt);
            this.Controls.Add(this.button_test);
            this.Controls.Add(this.lottoLogo);
            this.Controls.Add(this.label_num7);
            this.Controls.Add(this.label_num4);
            this.Controls.Add(this.label_num5);
            this.Controls.Add(this.label_num6);
            this.Controls.Add(this.label_num3);
            this.Controls.Add(this.label_num2);
            this.Controls.Add(this.label_num1);
            this.Controls.Add(this.gongImg_7);
            this.Controls.Add(this.gongImg_6);
            this.Controls.Add(this.gongImg_5);
            this.Controls.Add(this.gongImg_4);
            this.Controls.Add(this.gongImg_3);
            this.Controls.Add(this.gongImg_2);
            this.Controls.Add(this.gongImg_1);
            this.Controls.Add(this.thisPcent_7);
            this.Controls.Add(this.thisPcent_4);
            this.Controls.Add(this.thisPcent_5);
            this.Controls.Add(this.thisPcent_6);
            this.Controls.Add(this.thisPcent_3);
            this.Controls.Add(this.thisPcent_2);
            this.Controls.Add(this.thisPcent_1);
            this.Controls.Add(this.makeRandTxtBox);
            this.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(130, 0);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "로또번호 생성기 v1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lottoLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gongImg_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_test;
        private System.Windows.Forms.Label label_num1;
        private System.Windows.Forms.Label label_num2;
        private System.Windows.Forms.Label label_num3;
        private System.Windows.Forms.Label label_num4;
        private System.Windows.Forms.Label label_num5;
        private System.Windows.Forms.Label label_num6;
        private System.Windows.Forms.Label label_num7;
        private System.Windows.Forms.Label thisPcent_7;
        private System.Windows.Forms.Label thisPcent_4;
        private System.Windows.Forms.Label thisPcent_5;
        private System.Windows.Forms.Label thisPcent_6;
        private System.Windows.Forms.Label thisPcent_3;
        private System.Windows.Forms.Label thisPcent_2;
        private System.Windows.Forms.Label thisPcent_1;
        private System.Windows.Forms.PictureBox lottoLogo;
        private System.Windows.Forms.PictureBox gongImg_1;
        private System.Windows.Forms.PictureBox gongImg_2;
        private System.Windows.Forms.PictureBox gongImg_3;
        private System.Windows.Forms.PictureBox gongImg_6;
        private System.Windows.Forms.PictureBox gongImg_5;
        private System.Windows.Forms.PictureBox gongImg_4;
        private System.Windows.Forms.PictureBox gongImg_7;
        private VerticalTextBox makeRandTxtBox;
        private Sunny.UI.UILabel HelpLabelTxt;
    }
}

