﻿using System.Windows.Forms;

namespace EmartIbgu_Kiosk
{
    public partial class _1st_Main : UserControl
    {
        public _1st_Main()
        {
            InitializeComponent();
        }
    }
}
