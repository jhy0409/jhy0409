﻿using System.Windows.Forms;

namespace EmartIbgu_Kiosk
{
    public partial class _4th_customerCenter : UserControl
    {
        public _4th_customerCenter()
        {
            InitializeComponent();
        }
    }
}
