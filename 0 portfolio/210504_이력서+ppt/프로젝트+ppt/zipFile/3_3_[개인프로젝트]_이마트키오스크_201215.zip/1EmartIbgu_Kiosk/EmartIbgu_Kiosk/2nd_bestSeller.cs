﻿using System;
using System.Windows.Forms;

namespace EmartIbgu_Kiosk
{
    public partial class _2nd_bestSeller : UserControl
    {
        public _2nd_bestSeller()
        {
            InitializeComponent();
        }

        private void _2nd_bestSeller_Load(object sender, EventArgs e)
        {

        }
    }
}
